#!/usr/bin/env python3
"""
Domain Name Services (DNS) - Custom DNS Resolver
A high-performance, lightweight DNS resolver built from the ground up.
This implements all 6 layers of DNS resolution:
- Layer 1: UDP Transport
- Layer 2: Binary Header Parser
- Layer 3: Label Decoder
- Layer 4: Response Constructor
- Layer 5: Zone Files (JSON Database)
- Layer 6: Recursive Resolver
"""

import socket
import struct
import json
import sys
import os

# Configuration
DEFAULT_PORT = 8053
DEFAULT_ZONE_FILE = "zones.json"
UPSTREAM_DNS = ("8.8.8.8", 53)
BUFFER_SIZE = 512


def parse_header(data):
    """
    Layer 2: Binary Header Parser
    Unpacks the 12-byte DNS header into readable components.
    """
    header = struct.unpack("!HHHHHH", data[:12])
    return {
        "ID": header[0],
        "Flags": header[1],
        "QDCOUNT": header[2],  # Question Count
        "ANCOUNT": header[3],  # Answer Count
        "NSCOUNT": header[4],   # Authority Count
        "ARCOUNT": header[5]   # Additional Count
    }


def decode_labels(data, offset):
    """
    Layer 3: Label Decoder
    Converts DNS label encoding (e.g., 06google03com) to readable domain names.
    """
    labels = []
    while True:
        length = data[offset]
        if length == 0:  # End of domain name
            offset += 1
            break
        offset += 1
        label = data[offset:offset + length].decode("ascii")
        labels.append(label)
        offset += length
    return ".".join(labels), offset


def build_response(data, domain_name, ip_address=None, ttl=300):
    """
    Layer 4: Response Constructor
    Builds a binary DNS response packet with the answer section.
    """
    transaction_id = data[:2]
    
    if ip_address:
        # Standard response with answer
        flags = b'\x81\x80'  # QR=1 (response), AA=1, RA=1, No error
        ancount = b'\x00\x01'
    else:
        # NXDOMAIN - Domain not found
        flags = b'\x81\x83'  # Error code 3 (NXDOMAIN)
        ancount = b'\x00\x00'
        ip_address = "0.0.0.0"
    
    counts = b'\x00\x01' + ancount + b'\x00\x00\x00\x00'
    header = transaction_id + flags + counts
    
    # Question Section (reuse from original query)
    _, offset = decode_labels(data, 12)
    question_section = data[12:offset + 4]
    
    if ip_address and ip_address != "0.0.0.0":
        # Build Answer Section
        name_pointer = b'\xc0\x0c'  # Pointer to domain name at offset 12
        type_class = b'\x00\x01\x00\x01'  # Type A, Class IN
        ttl_bytes = struct.pack("!I", ttl)  # TTL as 4-byte integer
        rd_length = b'\x00\x04'  # IPv4 address is 4 bytes
        ip_bytes = socket.inet_aton(ip_address)
        answer_section = name_pointer + type_class + ttl_bytes + rd_length + ip_bytes
        return header + question_section + answer_section
    else:
        return header + question_section


def load_zones(zone_file=DEFAULT_ZONE_FILE):
    """
    Layer 5: Zone File Loader
    Loads the JSON-based zone database.
    """
    try:
        with open(zone_file) as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Warning: {zone_file} not found. Using empty zones.")
        return {}
    except json.JSONDecodeError as e:
        print(f"Error parsing {zone_file}: {e}")
        return {}


def forward_query(data):
    """
    Layer 6: Recursive Forwarding
    Forwards unknown queries to upstream DNS server (8.8.8.8).
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as forward_sock:
            forward_sock.settimeout(2.0)
            forward_sock.sendto(data, UPSTREAM_DNS)
            answer, _ = forward_sock.recvfrom(BUFFER_SIZE)
            return answer
    except socket.timeout:
        print("Upstream DNS timeout")
        return None
    except Exception as e:
        print(f"Forward error: {e}")
        return None


def handle_query(data, addr, zones):
    """
    Main query handler - implements the decision tree:
    1. Check local zones first
    2. Forward to upstream if not found
    3. Return NXDOMAIN if both fail
    """
    # Parse the domain name from the query
    domain_name, _ = decode_labels(data, 12)
    print(f"Query from {addr}: {domain_name}")
    
    # Layer 5: Check local zones
    if domain_name in zones:
        zone = zones[domain_name]
        ip_address = zone.get("A")
        ttl = zone.get("ttl", 300)
        
        response = build_response(data, domain_name, ip_address, ttl)
        print(f"  -> Local hit: {domain_name} -> {ip_address}")
        return response
    
    # Layer 6: Forward to upstream DNS
    print(f"  -> Forwarding to upstream DNS...")
    response = forward_query(data)
    
    if response:
        print(f"  -> Upstream response received")
        return response
    
    # Fallback: Return NXDOMAIN
    print(f"  -> No answer available, returning NXDOMAIN")
    return build_response(data, domain_name, None)


def start_server(port=DEFAULT_PORT, zone_file=DEFAULT_ZONE_FILE):
    """
    Layer 1: UDP Transport
    Starts the DNS server on the specified port.
    """
    # Load zones
    zones = load_zones(zone_file)
    print(f"Loaded {len(zones)} zone entries from {zone_file}")
    
    # Create UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        sock.bind(("0.0.0.0", port))
        print(f"\n🚀 DNS Server started on port {port}")
        print(f"   Listening for queries...\n")
        
        while True:
            try:
                data, addr = sock.recvfrom(BUFFER_SIZE)
                
                # Parse header for debugging
                header = parse_header(data)
                
                # Handle the query
                response = handle_query(data, addr, zones)
                
                # Send response back to client
                if response:
                    sock.sendto(response, addr)
                    
            except KeyboardInterrupt:
                print("\n🛑 Shutting down DNS server...")
                break
            except Exception as e:
                print(f"Error handling query: {e}")
                
    except PermissionError:
        print(f"Error: Need sudo/admin to bind to port {port}")
        print(f"Try running with: sudo python3 {sys.argv[0]}")
        sys.exit(1)
    finally:
        sock.close()


def main():
    """Main entry point with command-line argument support."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Custom DNS Resolver - Layer by Layer Implementation"
    )
    parser.add_argument(
        "-p", "--port",
        type=int,
        default=DEFAULT_PORT,
        help=f"DNS server port (default: {DEFAULT_PORT})"
    )
    parser.add_argument(
        "-z", "--zones",
        type=str,
        default=DEFAULT_ZONE_FILE,
        help=f"Zone file path (default: {DEFAULT_ZONE_FILE})"
    )
    
    args = parser.parse_args()
    
    print("=" * 50)
    print("  Domain Name Services (DNS) - Custom Resolver")
    print("  6-Layer DNS Implementation")
    print("=" * 50)
    
    start_server(args.port, args.zones)


if __name__ == "__main__":
    main()
